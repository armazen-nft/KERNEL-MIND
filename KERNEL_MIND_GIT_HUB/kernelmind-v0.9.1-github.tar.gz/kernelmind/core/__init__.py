"""KernelMind Core — sensor, memory analysis, storage guard."""
__version__ = "0.9.1"
