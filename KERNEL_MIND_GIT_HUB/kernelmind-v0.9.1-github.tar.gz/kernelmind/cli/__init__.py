"""KernelMind CLI — command line interface."""
