"""KernelMind API — FastAPI REST server."""
