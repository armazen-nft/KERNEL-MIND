"""KernelMind EthicsLock — immutable ethical constraint layer."""
