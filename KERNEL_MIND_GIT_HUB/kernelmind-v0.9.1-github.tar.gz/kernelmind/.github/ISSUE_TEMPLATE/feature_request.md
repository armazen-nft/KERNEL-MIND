---
name: Feature request
about: Sugestão de nova funcionalidade
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

**Contexto**
Que problema esta funcionalidade resolveria?

**Proposta**
Descreva o que você gostaria que existisse.

**Alternativas consideradas**
Existe alguma forma atual de resolver isso?

**Impacto ético**
Esta funcionalidade requer alguma ação que poderia afetar o EthicsLock?
[ ] Sim (descreva abaixo) [ ] Não

**Contexto adicional**
Qualquer outra informação relevante.
