---
name: Bug report
about: Algo não está funcionando
title: '[BUG] '
labels: bug
assignees: ''
---

**Descrição**
Descreva o problema de forma clara.

**Reprodução**
Passos para reproduzir:
1. ...
2. ...

**Comportamento esperado**
O que deveria acontecer.

**Comportamento atual**
O que está acontecendo.

**Ambiente**
- OS: [ex: Ubuntu 24.04]
- Kernel: [ex: 6.8.0] (resultado de `uname -r`)
- Python: [ex: 3.12.3] (resultado de `python3 --version`)
- KernelMind: [ex: 0.9.1]

**Logs**
```
Cole aqui a saída de `km snapshot` ou o traceback do erro
```

**EthicsLock**
O problema envolve alguma ação que o EthicsLock bloqueou? [ ] Sim [ ] Não
