"""Tests for KernelSense — verifies real system reads."""
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.sensor import KernelSense, SystemSnapshot, CPUMetrics, MemoryMetrics, DiskMetrics
from dataclasses import asdict


@pytest.fixture
def sensor():
    return KernelSense()


def test_cpu_returns_valid_percent(sensor):
    cpu = sensor.cpu()
    assert 0.0 <= cpu.percent <= 100.0


def test_cpu_has_cores(sensor):
    cpu = sensor.cpu()
    assert cpu.cores_logical >= 1
    assert cpu.cores_physical >= 1


def test_memory_totals_consistent(sensor):
    mem = sensor.memory()
    assert mem.total_mb > 0
    assert mem.used_mb <= mem.total_mb
    assert mem.available_mb <= mem.total_mb
    assert 0.0 <= mem.percent <= 100.0


def test_disk_free_plus_used_leq_total(sensor):
    disk = sensor.disk()
    assert disk.total_gb > 0
    assert disk.free_gb >= 0
    assert disk.used_gb >= 0
    # free + used may differ from total due to reserved blocks — just check bounds
    assert disk.used_gb <= disk.total_gb
    assert 0.0 <= disk.percent <= 100.0


def test_top_processes_list(sensor):
    procs = sensor.top_processes(5)
    assert isinstance(procs, list)
    assert len(procs) <= 5
    for p in procs:
        assert p.pid > 0
        assert isinstance(p.name, str)
        assert p.cpu_percent >= 0.0
        assert p.mem_mb >= 0.0


def test_snapshot_structure(sensor):
    snap = sensor.snapshot()
    assert isinstance(snap, SystemSnapshot)
    assert snap.timestamp > 0
    assert snap.kernel_version != ""
    assert snap.uptime_hours >= 0
    d = asdict(snap)
    assert "cpu" in d
    assert "memory" in d
    assert "disks" in d


def test_snapshot_serializable(sensor):
    """Snapshot deve ser serializável para JSON (API + MCP)."""
    import json
    snap = sensor.snapshot()
    result = json.dumps(asdict(snap), default=str)
    assert len(result) > 100
