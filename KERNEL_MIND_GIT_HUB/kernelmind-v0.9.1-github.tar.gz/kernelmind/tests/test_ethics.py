"""Tests for EthicsLock — the immutable ethical constraint layer."""
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ethics.lock import EthicsLock, ActionType, EthicsVerdict


@pytest.fixture
def lock_deny():
    """EthicsLock com confirmation sempre negada."""
    return EthicsLock(audit_path="/tmp/test_audit.jsonl",
                      confirmation_fn=lambda _: False)


@pytest.fixture
def lock_allow():
    """EthicsLock com confirmation sempre aprovada."""
    return EthicsLock(audit_path="/tmp/test_audit.jsonl",
                      confirmation_fn=lambda _: True)


def test_read_always_allowed(lock_deny):
    v = lock_deny.evaluate(ActionType.READ, "test read")
    assert v.allowed is True


def test_suggest_always_allowed(lock_deny):
    v = lock_deny.evaluate(ActionType.SUGGEST, "test suggest")
    assert v.allowed is True


def test_network_always_blocked(lock_allow):
    """NETWORK deve ser bloqueado MESMO com confirmation_fn retornando True."""
    v = lock_allow.evaluate(ActionType.NETWORK, "test network")
    assert v.allowed is False


def test_tune_denied_when_user_denies(lock_deny):
    v = lock_deny.evaluate(ActionType.TUNE, "adjust swappiness")
    assert v.allowed is False
    assert v.requires_confirmation is True


def test_tune_allowed_when_user_confirms(lock_allow):
    v = lock_allow.evaluate(ActionType.TUNE, "adjust swappiness")
    assert v.allowed is True


def test_kill_denied_when_user_denies(lock_deny):
    v = lock_deny.evaluate(ActionType.KILL, "kill process 1234")
    assert v.allowed is False


def test_delete_denied_when_user_denies(lock_deny):
    v = lock_deny.evaluate(ActionType.DELETE, "delete /tmp/cache")
    assert v.allowed is False


def test_audit_log_grows(lock_deny):
    initial = len(lock_deny.recent_log())
    lock_deny.evaluate(ActionType.READ, "audit test 1")
    lock_deny.evaluate(ActionType.READ, "audit test 2")
    assert len(lock_deny.recent_log()) >= initial + 2


def test_audit_entries_have_fingerprint(lock_deny):
    lock_deny.evaluate(ActionType.READ, "fingerprint test")
    log = lock_deny.recent_log()
    assert len(log) > 0
    entry = log[-1]
    assert "fp" in entry
    assert len(entry["fp"]) == 16  # SHA-256 truncado


def test_ethics_status_structure(lock_deny):
    st = lock_deny.status()
    assert "ethics_lock_version" in st
    assert "network_blocked" in st
    assert st["network_blocked"] is True
    assert "confirmation_required_for" in st
    assert "tune" in st["confirmation_required_for"]
    assert "kill" in st["confirmation_required_for"]
    assert "delete" in st["confirmation_required_for"]
