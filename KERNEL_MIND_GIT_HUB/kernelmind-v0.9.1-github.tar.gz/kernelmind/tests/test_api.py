"""Tests for FastAPI REST server endpoints."""
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from fastapi.testclient import TestClient
    from api.server import app
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False


@pytest.fixture
def client():
    if not HAS_FASTAPI:
        pytest.skip("fastapi/httpx not installed")
    return TestClient(app)


def test_root(client):
    r = client.get("/")
    assert r.status_code == 200
    data = r.json()
    assert data["name"] == "KernelMind"
    assert "ethics" in data


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"
    assert r.json()["ethics_lock"] == "active"


def test_snapshot_structure(client):
    r = client.get("/snapshot")
    assert r.status_code == 200
    data = r.json()
    assert "cpu" in data
    assert "memory" in data
    assert "disks" in data
    assert "top_processes" in data
    assert "timestamp" in data


def test_cpu_endpoint(client):
    r = client.get("/cpu")
    assert r.status_code == 200
    data = r.json()
    assert "percent" in data
    assert 0 <= data["percent"] <= 100


def test_memory_endpoint(client):
    r = client.get("/memory")
    assert r.status_code == 200
    data = r.json()
    assert "total_mb" in data
    assert data["total_mb"] > 0


def test_memory_suggest(client):
    r = client.get("/memory/suggest")
    assert r.status_code == 200
    data = r.json()
    assert "count" in data
    assert "suggestions" in data
    assert isinstance(data["suggestions"], list)


def test_disk_endpoint(client):
    r = client.get("/disk")
    assert r.status_code == 200
    data = r.json()
    assert "total_gb" in data
    assert data["total_gb"] > 0


def test_ethics_status(client):
    r = client.get("/ethics/status")
    assert r.status_code == 200
    data = r.json()
    assert data["network_blocked"] is True


def test_ethics_log(client):
    r = client.get("/ethics/log")
    assert r.status_code == 200
    data = r.json()
    assert "entries" in data
    assert isinstance(data["entries"], list)
